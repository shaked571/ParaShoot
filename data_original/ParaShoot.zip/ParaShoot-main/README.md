# ParaShoot
A Hebrew Question Answering Dataset
